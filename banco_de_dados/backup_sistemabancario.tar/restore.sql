--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sistema_bancario;
--
-- Name: sistema_bancario; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE sistema_bancario WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE sistema_bancario OWNER TO postgres;

\connect sistema_bancario

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE sistema_bancario; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE sistema_bancario IS 'Banco de dados para armazenar os dados do sistema bancário implementado durante o desenvolvimento do projeto do Bootcamp "Potência Tech: Ciência de Dados com Python" da DIO..';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agencia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agencia (
    id_agencia character varying(6) NOT NULL,
    nome character varying(255) NOT NULL,
    rua character varying(255) NOT NULL,
    cidade character varying(100) NOT NULL,
    estado character(2) NOT NULL
);


ALTER TABLE public.agencia OWNER TO postgres;

--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente (
    id_cliente integer NOT NULL,
    nome character varying(255) NOT NULL,
    data_nascimento date NOT NULL,
    cpf character(11) NOT NULL,
    rg character varying(15) NOT NULL,
    telefone character(11) NOT NULL,
    email character varying(255)
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- Name: cliente_id_cliente_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cliente_id_cliente_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cliente_id_cliente_seq OWNER TO postgres;

--
-- Name: cliente_id_cliente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cliente_id_cliente_seq OWNED BY public.cliente.id_cliente;


--
-- Name: conta_bancaria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conta_bancaria (
    id_conta character varying(11) NOT NULL,
    agencia_id character varying(6) NOT NULL,
    cliente_id integer NOT NULL,
    saldo_atual numeric(15,2) NOT NULL,
    saldo_disponivel numeric(15,2) NOT NULL,
    tipo_conta character varying(20) NOT NULL,
    status_conta character varying(20) NOT NULL,
    data_criacao date NOT NULL,
    data_fechamento date,
    senha_hash character varying(100) NOT NULL
);


ALTER TABLE public.conta_bancaria OWNER TO postgres;

--
-- Name: conta_bancaria_cliente_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.conta_bancaria_cliente_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.conta_bancaria_cliente_id_seq OWNER TO postgres;

--
-- Name: conta_bancaria_cliente_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.conta_bancaria_cliente_id_seq OWNED BY public.conta_bancaria.cliente_id;


--
-- Name: transacao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transacao (
    id_transacao integer NOT NULL,
    conta_id character varying(11) NOT NULL,
    tipo character varying(10) NOT NULL,
    data_transacao date NOT NULL,
    valor numeric(15,2) NOT NULL,
    saldo_final numeric(15,2) NOT NULL,
    saldo_inicial numeric(15,2) NOT NULL,
    CONSTRAINT transacao_tipo_check CHECK (((tipo)::text = ANY ((ARRAY['deposito'::character varying, 'saque'::character varying])::text[])))
);


ALTER TABLE public.transacao OWNER TO postgres;

--
-- Name: transacao_id_transacao_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transacao_id_transacao_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transacao_id_transacao_seq OWNER TO postgres;

--
-- Name: transacao_id_transacao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transacao_id_transacao_seq OWNED BY public.transacao.id_transacao;


--
-- Name: cliente id_cliente; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente ALTER COLUMN id_cliente SET DEFAULT nextval('public.cliente_id_cliente_seq'::regclass);


--
-- Name: conta_bancaria cliente_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conta_bancaria ALTER COLUMN cliente_id SET DEFAULT nextval('public.conta_bancaria_cliente_id_seq'::regclass);


--
-- Name: transacao id_transacao; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transacao ALTER COLUMN id_transacao SET DEFAULT nextval('public.transacao_id_transacao_seq'::regclass);


--
-- Data for Name: agencia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agencia (id_agencia, nome, rua, cidade, estado) FROM stdin;
\.
COPY public.agencia (id_agencia, nome, rua, cidade, estado) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cliente (id_cliente, nome, data_nascimento, cpf, rg, telefone, email) FROM stdin;
\.
COPY public.cliente (id_cliente, nome, data_nascimento, cpf, rg, telefone, email) FROM '$$PATH$$/3347.dat';

--
-- Data for Name: conta_bancaria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conta_bancaria (id_conta, agencia_id, cliente_id, saldo_atual, saldo_disponivel, tipo_conta, status_conta, data_criacao, data_fechamento, senha_hash) FROM stdin;
\.
COPY public.conta_bancaria (id_conta, agencia_id, cliente_id, saldo_atual, saldo_disponivel, tipo_conta, status_conta, data_criacao, data_fechamento, senha_hash) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: transacao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transacao (id_transacao, conta_id, tipo, data_transacao, valor, saldo_final, saldo_inicial) FROM stdin;
\.
COPY public.transacao (id_transacao, conta_id, tipo, data_transacao, valor, saldo_final, saldo_inicial) FROM '$$PATH$$/3352.dat';

--
-- Name: cliente_id_cliente_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cliente_id_cliente_seq', 1, true);


--
-- Name: conta_bancaria_cliente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.conta_bancaria_cliente_id_seq', 1, false);


--
-- Name: transacao_id_transacao_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transacao_id_transacao_seq', 59, true);


--
-- Name: agencia agencia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agencia
    ADD CONSTRAINT agencia_pkey PRIMARY KEY (id_agencia);


--
-- Name: cliente cliente_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_email_key UNIQUE (email);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (id_cliente);


--
-- Name: conta_bancaria conta_bancaria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conta_bancaria
    ADD CONSTRAINT conta_bancaria_pkey PRIMARY KEY (id_conta);


--
-- Name: transacao transacao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transacao
    ADD CONSTRAINT transacao_pkey PRIMARY KEY (id_transacao);


--
-- Name: conta_bancaria conta_bancaria_agencia_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conta_bancaria
    ADD CONSTRAINT conta_bancaria_agencia_id_fkey FOREIGN KEY (agencia_id) REFERENCES public.agencia(id_agencia);


--
-- Name: conta_bancaria conta_bancaria_cliente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conta_bancaria
    ADD CONSTRAINT conta_bancaria_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.cliente(id_cliente);


--
-- Name: transacao transacao_conta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transacao
    ADD CONSTRAINT transacao_conta_id_fkey FOREIGN KEY (conta_id) REFERENCES public.conta_bancaria(id_conta);


--
-- PostgreSQL database dump complete
--

